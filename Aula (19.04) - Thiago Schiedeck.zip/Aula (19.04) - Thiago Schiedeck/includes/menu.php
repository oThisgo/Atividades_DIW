<header id="top-menu">
    <a href="#"><img id="logosenac" src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/86/Senac_logo.svg/1200px-Senac_logo.svg.png"></a>
    <ul id="menu_list">
        <li><a id="menu_links" href="#">🐶 Cachorro</a></li>
        <li><a id="menu_links" href="#">😺 Gato</a></li>
        <li><a id="menu_links" href="#">🦖 Dinossauro</a></li>
    </ul>
</header>
