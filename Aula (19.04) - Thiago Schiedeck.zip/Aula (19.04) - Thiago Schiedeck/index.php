<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <title>Ivonas</title>
</head>

<?php
include_once 'includes/menu.php';
?>

<body>
    <h3>Lojinha</h3>
    
    <ul id="grade_produtos">
        <li style="display: inline-block;">
            <div id="produtos"> 
                <img id="fotoproduto" src="https://martinelloeletrodomesticos.fbitsstatic.net/img/p/brinquedo-divertoys-dinossauro-diver-dinos-t-rex-8193-78033/264625.jpg?w=482&h=482&v=no-change&qs=ignore">
                <a id="nome" href="#"><h5>Dino</h5>
                <a id="preco" href="#"><h4>R$ 19.999,99<h4>
            </div>
        </li>
        <li>
            <div id="produtos"> 
                <img id="fotoproduto" src="https://martinelloeletrodomesticos.fbitsstatic.net/img/p/brinquedo-divertoys-dinossauro-diver-dinos-t-rex-8193-78033/264625.jpg?w=482&h=482&v=no-change&qs=ignore">
                <a id="nome" href="#"><h5>Dino</h5>
                <a id="preco" href="#"><h4>R$ 19.999,99<h4>
            </div>
        </li>
        <li>
            <div id="produtos"> 
                <img id="fotoproduto" src="https://martinelloeletrodomesticos.fbitsstatic.net/img/p/brinquedo-divertoys-dinossauro-diver-dinos-t-rex-8193-78033/264625.jpg?w=482&h=482&v=no-change&qs=ignore">
                <a id="nome" href="#"><h5>Dino</h5>
                <a id="preco" href="#"><h4>R$ 19.999,99<h4>
            </div>
        </li>
    <ul>
</body>

</html>