<!DOCTYPE html>
<html lang="pt-Br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="styles.css" rel="stylesheet">
    <title>Ivonas</title>
</head>
<body>
    <h1 style="text-align: center; font-family: arial; font-weight: bold;">TEQUILA</h1>
    <img id="tequila" src="https://cdn.dooca.store/29663/products/1iwsk92u8z2hdwpd5aaf6dpoijjy69zkqzpe_640x640+fill_ffffff.png?v=1651511830&webp=0">
</body>
</html>