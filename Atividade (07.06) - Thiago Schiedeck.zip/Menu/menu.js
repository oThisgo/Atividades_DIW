function openNav() {
    document.getElementById("menulateral").style.width = "250px";
    document.getElementById("conteudo").style.marginLeft = "250px";
}

function closeNav() {
    document.getElementById("menulateral").style.width = "0";
    document.getElementById("conteudo").style.marginLeft = "0";
}