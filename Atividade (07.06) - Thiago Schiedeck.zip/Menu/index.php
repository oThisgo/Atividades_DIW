<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <script src="menu.js"></script>
    <title>MENU</title>
</head>

<header>

    <div id="menulateral" class="menu">
        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
        <a href="#">Sobre</a>
        <a href="#">Serviços</a>
        <a href="#">Clientes</a>
        <a href="#">Contato</a>
    </div>

    <span style="font-size:30px; cursor:pointer; color: white;" onclick="openNav()">&#9776;</span>

</header>

<body id="conteudo">
    <img id="computador" src="img/computador.jpeg">
</body>

</html>