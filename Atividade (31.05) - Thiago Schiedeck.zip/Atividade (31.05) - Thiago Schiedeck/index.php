<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="styles.css" rel="stylesheet">
    <title>Document</title>
</head>

<body>

<style>
.dropbtn {
  color: white;
  background-color: transparent;
  font-size: 16px;
  font-weight: bold;
  border: none;
  cursor: pointer;
}

.dropdown {
  position: absolute;
  display: inline-block;
  left: 1%;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: black;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
  border-radius: 25px;
}

.dropdown-content a {
  color: white;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {
    border-radius: 25px;
    font-style: italic;
    background: -webkit-linear-gradient(yellow, orange, red);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.dropdown:hover .dropdown-content {
  display: block;
}

.dropdown:hover .dropbtn {
    font-style: italic;
    background: -webkit-linear-gradient(yellow, orange, red);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}
</style>

<nav id="menu-horizontal">
    <ul>
        <li><a href="#">Home</a></li>
        <div class="dropdown">
            <button class="dropbtn">Cursos</button>
            <div class="dropdown-content">
                <a href="#">ADS</a>
                <a href="#">RDS</a>
                <a href="#">PMM</a>
                <a href="#">SPI</a>
                <a href="#">CD&IA</a>
                <a href="#">DC</a>
            </div>
        </div>
        <li><a href="#">Quem Somos</a></li>
        <li><a href="#">Sobre Nós</a></li>
        <li><a style="position: absolute; right: 1.5%; top: 37.5%;" href="#">Entrar</a></li>
    </ul>    
</nav>

</body>

</html>