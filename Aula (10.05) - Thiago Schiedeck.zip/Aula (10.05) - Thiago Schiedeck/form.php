<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="style.css" rel="stylesheet">
    <title>Formulário</title>
</head>
<body>
    <div id="container">

        <?php
            $date = str_replace('-', '/', $_POST["nascimento"]);

            echo "Olá, ".$_POST["nome"].", por favor, confirme seus dados abaixo:<br><br>";
            echo "Seu email: ".$_POST["email"]."<br><br>";
            echo "Seu telefone: ".$_POST["telefone"]."<br><br>";
            echo "Seu gênero: ".$_POST["genero"]."<br><br>";
            echo "Sua data de nascimento: ".$date."<br><br>";
            echo "Você mora no estado de ".$_POST["estado"]." na cidade de ".$_POST["cidade"].", seu bairro é ".$_POST["bairro"]." e seu endereço é Rua ".$_POST["rua"].", ".$_POST["numero"]."<br><br>";

            if (!isset(["complemento"])) {
                
            }
        ?>
    
    </div>
</body>
</html>