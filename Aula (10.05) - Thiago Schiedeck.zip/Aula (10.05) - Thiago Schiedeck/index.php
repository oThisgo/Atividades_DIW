<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="style.css" rel="stylesheet">
    <title>Formulário</title>
</head>
<body>
    <div id="container">
        <form action="form.php" method="post">
            <h3 style="text-align: center;">FORMULÁRIO</h3>
            <h5 style="margin-bottom: 3%; margin-top: 30px;">Informações pessoais:</h5>
            <input type="text" name="nome" placeholder="Nome Completo" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="tel" name="telefone" placeholder="Telefone" required>
            <h5 style="margin-bottom: 3%; margin-top: 10%;">Informe o seu gênero:</h5>
            <input style="display: inline-block;" type="radio" id="fem" name="genero" value="feminino" required>
            <label for="fem">Feminino</label>
            <input style="display: inline-block;" type="radio" id="masc" name="genero" value="masculino" required>
            <label for="masc">Masculino</label>
            <br>
            <input style="display: inline-block;" type="radio" id="outro" name="genero" value="outro" required>
            <label for="masc">Outro</label>
            <input style="display: inline-block;" type="radio" id="nao" name="genero" value="nao" required>
            <label for="masc">Prefiro não informar</label>
            <h5 style="margin-bottom: 3%; margin-top: 5%;">Data de nascimento:</h5>
            <input style="margin-bottom: 20px;" type="date" id="nasc" name="nascimento" value="nascimento" required>
            <h5 style="margin-bottom: 3%; margin-top: 7%;">Endereço:</h5>
            <input style="display: inline-block;" type="text" name="estado" placeholder="Estado" required>
            <input style="display: inline-block;" type="text" name="cidade" placeholder="Cidade" required>
            <br>
            <input style="display: inline-block;" type="text" name="bairro" placeholder="Bairro" required>
            <input style="display: inline-block;" type="text" name="rua" placeholder="Rua" required>
            <br>
            <input style="display: inline-block;" type="text" name="numero" placeholder="Número" required>
            <input style="display: inline-block;" type="text" name="comp" placeholder="Complemento">
            <input id="button" type="submit" name="button" value="ENVIAR">
        <form>
</body>
</html>