<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="icon" type="image/x-icon" href="https://imgs.ponto.com.br/1531721765/1xg.jpg">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <title>dINoSAuRiO</title>
</head>

<?php
include_once 'includes/menu.php';
?>
<body>

<img id="produto_detalhe" src="https://www.rbsdirect.com.br/imagesrc/25743537.jpg?w=700">
<h1 id="tag_caramelo">CACHORRO CAMARELO</h1>
<a id="buy_caramelo" href="#">COMPRAR</a>

<div id="caracteristicas">
    <ul id="info_caramelo">
        <li>Nome: Caramelo</li>
        <li>Idade: Desconhecida</li>
        <li>Validade: Imensurável</li>
        <li>Traços de personalidade: Impulsivo, amigável, destruidor, inocente, ex-presidiário...</li>
    </ul>
</div>

</body>

</html>