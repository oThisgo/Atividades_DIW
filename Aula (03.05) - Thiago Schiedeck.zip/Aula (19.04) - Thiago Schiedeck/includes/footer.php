<footer>
    <p id="copyright">Site por &copyThiago Xiedeque</p>
</footer>