<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="icon" type="image/x-icon" href="https://imgs.ponto.com.br/1531721765/1xg.jpg">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <title>dINoSAuRiO</title>
</head>

<?php
include_once 'includes/menu.php';
?>

<body>
    <h3>LOJINHA</h3>
    
    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3" style="width: 80%; margin-left: auto; margin-right: auto; margin-top: 20px;">
        <div class="col">
          <div class="card shadow-sm">
            <img class="bd-placeholder-img card-img-top" src="https://as1.ftcdn.net/v2/jpg/02/92/42/14/1000_F_292421465_75SBINQZPzEDv573z7MDcqWtlXdn6Yi4.jpg" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false">
            <div class="card-body">
              <h4 class="card-text">Dinosaurio</h4>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                    <button type="button" class="btn btn-sm btn-outline-secondary" style="color: green;"><a href="produto.php" style="text-decoration: none; color: green;">R$19.999,99</a></button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
          <img class="bd-placeholder-img card-img-top" src="https://classic.exame.com/wp-content/uploads/2016/09/size_960_16_9_20151019-26684-1qsq7cj.jpg?quality=70&strip=info&w=960" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false">
            <div class="card-body">
                <h4 class="card-text">Dinosaurio</h4>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary" style="color: green; ">R$19.999,99</button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
          <img class="bd-placeholder-img card-img-top" src="https://m.media-amazon.com/images/I/51jizo6mwaL._AC_UF1000,1000_QL80_.jpg" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false">
            <div class="card-body">
                <h4 class="card-text">Dinosaurio</h4>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                    <button type="button" class="btn btn-sm btn-outline-secondary" style="color: green; ">R$19.999,99</button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="col">
          <div class="card shadow-sm">
            <img class="bd-placeholder-img card-img-top" src="https://as1.ftcdn.net/v2/jpg/04/78/46/60/1000_F_478466049_nQWd2SwiqKydz1nmQpsS20G46k1sAvGG.jpg" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false">
            <div class="card-body">
                <h4 class="card-text">Dinosaurio</h4>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                    <button type="button" class="btn btn-sm btn-outline-secondary" style="color: green; ">R$19.999,99</button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
            <img class="bd-placeholder-img card-img-top" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQDF_-ug8vfY31qiz4C2ti9va7e8Y5HWCwcRbnrbPyveQ9S51nsmK26sPV9YW78QpSuqYo&usqp=CAU" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false">
            <div class="card-body">
            <h4 class="card-text">Dinosaurio</h4>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                    <button type="button" class="btn btn-sm btn-outline-secondary" style="color: green; ">R$19.999,99</button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
            <img class="bd-placeholder-img card-img-top" src="https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/i/bf2c5b15-591e-4e52-9f29-9080e6589898/de924ue-b7d5a08e-3bcd-48f0-bd4a-c8096296da36.png/v1/fill/w_560,h_560,q_80,strp/yee_dino_meme_5_by_elizabethjones18_de924ue-fullview.jpg" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false">
            <div class="card-body">
                <h4 class="card-text">Dinosaurio</h4>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                    <button type="button" class="btn btn-sm btn-outline-secondary" style="color: green; ">R$19.999,99</button>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>
</body>

<?php
include_once 'includes/footer.php';
?>

</html>