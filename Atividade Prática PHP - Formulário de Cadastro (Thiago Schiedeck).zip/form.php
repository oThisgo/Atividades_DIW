<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="style.css" rel="stylesheet">
    <title>Formulário de Cadastro</title>
</head>
<body>
    <div id="container">

        <?php

            echo "Olá, ".$_POST["nome"]." ".$_POST["sobrenome"].", por favor, confirme seus dados abaixo:<br><br>";
            echo "Seu email: ".$_POST["email"]."<br><br>";
            echo "Seu telefone: ".$_POST["telefone"]."<br><br>";
            echo "Sua área: ".$_POST["area"]."<br><br>";
            echo "Sua experiência: ".$_POST["xp"]."<br><br>";
            echo "Um pouco sobre você: <br>".$_POST["desc"]."<br><br>";
            echo "<a style=\"text-decoration: none;\" href=\"index.php\"><input id=\"button\" type=\"submit\" name=\"button\" value=\"Voltar\"></a>";
            echo "<a style=\"text-decoration: none;\" href=\"sucesso.php\"><input id=\"button\" type=\"submit\" name=\"button\" value=\"Confirmar\">";

        ?>
    
    </div>
</body>
</html>