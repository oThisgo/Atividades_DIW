<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="style.css" rel="stylesheet">
    <title>Formulário de Cadastro</title>
</head>
<body>
    <div id="container">
        <form action="form.php" method="post">
            <h3 style="text-align: center;">FORMULÁRIO DE CADASTRO</h3>

            <h5 style="margin-bottom: 3%; margin-top: 30px;">Dados pessoais:</h5>
            <input style="display: inline-block;" type="text" name="nome" placeholder="Nome" required>
            <input style="display: inline-block;" type="text" name="sobrenome" placeholder="Sobrenome" required>
            <br>
            <input style="display: inline-block;" type="email" name="email" placeholder="Email" required>
            <input style="display: inline-block;" type="tel" name="telefone" placeholder="Telefone" required>

            <h5 style="margin-bottom: 3%; margin-top: 4.5%;">Área de desenvolvimento:</h5>
            <input style="display: inline-block;" type="radio" id="front" name="area" value="front-end" required>
            <label for="front">Front-end</label>
            <input style="display: inline-block;" type="radio" id="back" name="area" value="back-end" required>
            <label for="back">Back-end</label>
            <br>
            <input style="display: inline-block;" type="radio" id="full" name="area" value="full-stack" required>
            <label for="full">Fullstack</label>

            <h5 style="margin-bottom: 3%; margin-top: 5%;">Experiência:</h5>
            <select id="exp" name="xp" required>
                <option value="" disabled selected>-- Selecione --</option>
                <option value="iniciante">Iniciante</option>
                <option value="junior">Júnior</option>
                <option value="pleno">Pleno</option>
                <option value="senior">Senior</option>
            </select>

            <h5 style="margin-bottom: 3%; margin-top: 7%;">Tecnologias utilizadas:</h5>
            <div required>
                <input style="display: inline-block;" type="checkbox" id="html" name="linguagem">
                <label style="display: inline-block;" for="html">HTML</label>
                <input style="display: inline-block;" type="checkbox" id="css" name="linguagem">
                <label style="display: inline-block;" for="css">CSS</label>
                <br>
                <input style="display: inline-block;" type="checkbox" id="js" name="linguagem">
                <label style="display: inline-block;" for="js">JavaScript</label>
                <input style="display: inline-block;" type="checkbox" id="php" name="linguagem">
                <label style="display: inline-block;" for="php">PHP</label>
                <br>
                <input style="display: inline-block;" type="checkbox" id="c#" name="linguagem">
                <label style="display: inline-block;" for="c#">C#</label>
                <input style="display: inline-block;" type="checkbox" id="python" name="linguagem">
                <label style="display: inline-block;" for="python">Python</label>
                <input style="display: inline-block;" type="checkbox" id="java" name="linguagem">
                <label style="display: inline-block;" for="java">Java</label>
                <br>
            </div>

            <h5 style="margin-bottom: 3%; margin-top: 5%;">Conte um pouco sobre você:</h5>
            <textarea cols="30" rows="10" id="descricao" name="desc" required>
            </textarea>

            <input id="button" type="submit" name="button" value="ENVIAR">
        <form>
</body>
</html>